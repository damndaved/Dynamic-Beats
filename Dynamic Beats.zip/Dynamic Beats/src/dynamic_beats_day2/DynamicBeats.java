package dynamic_beats_day2;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class DynamicBeats extends JFrame{
	
	private Image screenImage;
	private Graphics screenGraphic;
	private Image introBackground = new ImageIcon(Main.class.getResource("../images/introBG(Title).jpg")).getImage();
	private JLabel menuBar = new JLabel (new ImageIcon(Main.class.getResource("../images/menuBar.jpg")));
	private JButton exitBtn = new JButton(new ImageIcon(Main.class.getResource("../images/exitBtnCopy.png")));
	private JButton exitBtnEntered = new JButton(new ImageIcon(Main.class.getResource("../images/exitBtnClicked.png")));


	public DynamicBeats() {
		
		
		
		setUndecorated(true);
		setTitle("Dynamic Beat");
		setSize(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setBackground(new Color(0, 0, 0, 0));
		setLayout(null);

		exitBtn.setBounds(1230, 0, 30, 30);
		exitBtn.setBorderPainted(false);
		exitBtn.setContentAreaFilled(false);
		exitBtn.setFocusPainted(false);
		add(exitBtn);
		menuBar.setBounds(0,0,1280,30);
		add(menuBar);


		Music introMusic = new Music("introMusic.mp3", true);
		introMusic.start();


	}


	public void paint(Graphics g) {

		screenImage = createImage(Main.SCREEN_WIDTH, Main.SCREEN_HEIGHT);
		screenGraphic = screenImage.getGraphics();		
		screenDraw(screenGraphic);
		g.drawImage(screenImage, 0, 0, null);

	}

	public void screenDraw(Graphics g) {

		g.drawImage(introBackground, 0, 0,null);
		paintComponents(g);
		this.repaint();

	}
}
